﻿using Microsoft.AspNetCore.Mvc;
using NewsPortalApp.Models;
using NewsPortalApp.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsPortalApp.Controllers
{

    // Controllers/NewsController.cs

    [ApiController]
    [Route("api/news")]
    public class NewsController : ControllerBase
    {
        private readonly INewsRepository _newsRepository;

        public NewsController(INewsRepository newsRepository)
        {
            _newsRepository = newsRepository;
        }

        [HttpGet("latest")]
        public IActionResult GetLatestNews(int page, int pageSize)
        {
            var news = _newsRepository.GetLatestNews(page, pageSize);
            return Ok(news);
        }

        [HttpGet("search")]
        public IActionResult SearchNews(string searchText)
        {
            var news = _newsRepository.SearchNews(searchText);
            return Ok(news);
        }

        [HttpGet("{id}")]
        public IActionResult GetNewsById(int id)
        {
            var news = _newsRepository.GetNewsById(id);
            if (news == null)
                return NotFound();

            return Ok(news);
        }

        [HttpPost]
        public IActionResult CreateNews([FromBody] NewsArticle newsArticle)
        {
            if (newsArticle == null)
                return BadRequest();

            _newsRepository.CreateNews(newsArticle);
            return CreatedAtAction(nameof(GetNewsById), new { id = newsArticle.Id }, newsArticle);
        }

        [HttpPut("{id}")]
        public IActionResult UpdateNews(int id, [FromBody] NewsArticle newsArticle)
        {
            if (newsArticle == null || id != newsArticle.Id)
                return BadRequest();

            var existingNews = _newsRepository.GetNewsById(id);
            if (existingNews == null)
                return NotFound();

            _newsRepository.UpdateNews(newsArticle);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public IActionResult DeleteNews(int id)
        {
            var news = _newsRepository.GetNewsById(id);
            if (news == null)
                return NotFound();

            _newsRepository.DeleteNews(id);
            return NoContent();
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<NewsArticle>>> GetNews([FromQuery] int page = 1, [FromQuery] int pageSize = 5)
        {
            var result = await _newsRepository.GetPagedNewsAsync(page, pageSize);
            return Ok(result);
        }
    }

}
