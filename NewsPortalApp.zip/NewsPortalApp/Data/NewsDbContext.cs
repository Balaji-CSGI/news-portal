﻿using Microsoft.EntityFrameworkCore;
using NewsPortalApp.Models;
using System.Collections.Generic;

namespace NewsPortalApp.Data
{
    public class NewsDbContext : DbContext
    {
        public NewsDbContext(DbContextOptions<NewsDbContext> options) : base(options) { }
        public DbSet<NewsArticle> NewsArticles { get; set; }
    }
}
