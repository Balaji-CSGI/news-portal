﻿using NewsPortalApp.Data;
using NewsPortalApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NewsPortalApp.Repositories
{
    public interface INewsRepository
    {
        IEnumerable<NewsArticle> GetLatestNews(int page, int pageSize);
        IEnumerable<NewsArticle> SearchNews(string searchText);
        NewsArticle GetNewsById(int id);
        void CreateNews(NewsArticle newsArticle);
        void UpdateNews(NewsArticle newsArticle);
        void DeleteNews(int id);
        Task<PaginationResult<NewsArticle>> GetPagedNewsAsync(int page, int pageSize);

    }
    public class PaginationResult<T>
    {
        public List<T> Items { get; set; }
        public int TotalItems { get; set; }
    }
    public class NewsRepository : INewsRepository
    {
        private readonly NewsDbContext _context;

        public NewsRepository(NewsDbContext context)
        {
            _context = context;
        }

        public IEnumerable<NewsArticle> GetLatestNews(int page, int pageSize)
        {
            int skip = (page - 1) * pageSize;
            return _context.NewsArticles
                .OrderByDescending(n => n.CreatedDateTime)
                .Skip(skip)
                .Take(pageSize)
                .ToList();
        }

        public IEnumerable<NewsArticle> SearchNews(string searchText)
        {
            return _context.NewsArticles
                .Where(n => n.Title.Contains(searchText) || n.Description.Contains(searchText))
                .OrderByDescending(n => n.CreatedDateTime)
                .ToList();
        }

        public NewsArticle GetNewsById(int id) 
        {
            return _context.NewsArticles.Find(id);
        }

        public void CreateNews(NewsArticle newsArticle)
        {
            newsArticle.CreatedDateTime = DateTime.Now;
            _context.NewsArticles.Add(newsArticle);
            _context.SaveChanges();
        }

        public void UpdateNews(NewsArticle newsArticle)
        {
            var existingNews = _context.NewsArticles.Find(newsArticle.Id);
            if (existingNews != null)
            {
                existingNews.Title = newsArticle.Title;
                existingNews.Description = newsArticle.Description;
                existingNews.Category = newsArticle.Category;
                // Update other properties as needed

                _context.SaveChanges();
            }
        }

        public void DeleteNews(int id)
        {
            var newsToDelete = _context.NewsArticles.Find(id);
            if (newsToDelete != null)
            {
                _context.NewsArticles.Remove(newsToDelete);
                _context.SaveChanges();
            }
        }
        public async Task<PaginationResult<NewsArticle>> GetPagedNewsAsync(int page, int pageSize)
        {
            var query = _context.NewsArticles.OrderByDescending(n => n.CreatedDateTime);

            var result = await PaginatedList<NewsArticle>.CreateAsync(query, page, pageSize);

            return new PaginationResult<NewsArticle>
            {
                Items = result.Items,
                TotalItems = result.TotalItems
            };
        }
    }

}
