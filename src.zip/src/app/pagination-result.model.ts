// pagination-result.model.ts

export interface PaginationResult<T> {
    totalItems: number;
    items: T[];
  }
  