export interface NewsArticle {
    id: number;
    title: string;
    description: string;
    category: string;
    createdDateTime: Date;
    // Add more properties as needed
  }