// news-edit.component.ts

import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NewsService } from '../news.service';
import { NewsArticle } from '../models/news-article.model';

@Component({
  selector: 'app-news-edit',
  templateUrl: './news-edit.component.html',
  styleUrls: ['./news-edit.component.css'],
})
export class NewsEditComponent implements OnInit {
  newsId!: number;
  newsArticle: NewsArticle = {
    id: 0,
    title: '', // Placeholder title
    description: '', // Placeholder description
    category: '', // Placeholder category
    createdDateTime: new Date(), // Placeholder date/time
    // add other properties with placeholder values as needed
  };

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private newsService: NewsService
  ) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      this.newsId = +params['id'];
      this.loadNewsArticle();
    });
  }

  loadNewsArticle() {
    // Fetch the actual values from the backend
    this.newsService.getNewsById(this.newsId).subscribe(article => {
      // Update the newsArticle with the values retrieved from the backend
      this.newsArticle = article || this.newsArticle;
    });
  }

   // Method to simulate getting values from the UI (replace with actual logic)
   private getValuesFromUI(): Partial<NewsArticle> {
    return {
      title: 'Updated Title from UI',
      description: 'Updated Description from UI',
      category: 'Updated Category from UI',
      // add other properties as needed
    };
  }

  updateNewsArticle() {
    this.newsService.updateNews(this.newsArticle).subscribe(() => {
      this.router.navigate(['/news-list']);
    });
  }
}
