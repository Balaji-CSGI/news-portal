// src/app/news-create/news-create.component.ts

import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NewsService } from '../news.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-news-create',
  templateUrl: './news-create.component.html',
  styleUrls: ['./news-create.component.css'],
})
export class NewsCreateComponent {
  newsForm: FormGroup;

  constructor(private fb: FormBuilder, private newsService: NewsService, private router: Router) {
    this.newsForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      category: ['', Validators.required],
      // Add more fields as needed
    });
  }

  createNews() {
    if (this.newsForm.valid) {
      this.newsService.createNews(this.newsForm.value).subscribe(() => {
        this.router.navigate(['/']);
      });
    }
  }
}
