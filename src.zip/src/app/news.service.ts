// src/app/news.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { NewsArticle } from './models/news-article.model';
import { PaginationResult } from './pagination-result.model';

@Injectable({
  providedIn: 'root'
})
export class NewsService {
  private apiUrl = 'https://localhost:5001/api/news';

  constructor(private http: HttpClient) {}

  // getPaginatedNews(page: number, pageSize: number): Observable<PaginationResult<NewsArticle>> {
  //   // Make an HTTP request to your backend API to get paginated news articles
  //   // Adjust the API endpoint based on your backend
  //   const url = `apiUtl/page=${page}&pageSize=${pageSize}`;
  //   return this.http.get<PaginationResult<NewsArticle>>(url);
  // }

  getLatestNews(page: number, pageSize: number): Observable<NewsArticle[]> {
    return this.http.get<NewsArticle[]>(`${this.apiUrl}/latest?page=${page}&pageSize=${pageSize}`);
  }

  searchNews(searchText: string): Observable<NewsArticle[]> {
    return this.http.get<NewsArticle[]>(`${this.apiUrl}/search?searchText=${searchText}`);
  }

  // getNewsById(id: number): Observable<NewsArticle> {
  //   return this.http.get<NewsArticle>(`${this.apiUrl}/${id}`);
  // }

  getNewsById(id: number): Observable<NewsArticle> {
    const url = `${this.apiUrl}/${id}`; // Adjust the endpoint based on your API
    return this.http.get<NewsArticle>(url);
  }

  createNews(newsArticle: NewsArticle): Observable<NewsArticle> {
    // Set the createdDateTime property to the current date and time
    newsArticle.createdDateTime = new Date();
    return this.http.post<NewsArticle>(`${this.apiUrl}`, newsArticle);
  }

  // updateNews(id: number, newsArticle: NewsArticle): Observable<void> {
  //   return this.http.put<void>(`${this.apiUrl}/${id}`, newsArticle);
  // }

  updateNews(article: NewsArticle): Observable<void> {
    const url = `${this.apiUrl}/${article.id}`; // Adjust the endpoint based on your API
    return this.http.put<void>(url, article);
  }

  deleteNews(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  getPaginatedNews(page: number, pageSize: number, searchTerm?: string): Observable<any> {
    let params = new HttpParams()
      .set('page', page.toString())
      .set('pageSize', pageSize.toString());

    if (searchTerm) {
      params = params.set('searchTerm', searchTerm);
    }

    return this.http.get(`${this.apiUrl}`, { params });
  }
}
