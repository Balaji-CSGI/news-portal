// src/app/news-list/news-list.component.ts

import { Component, AfterViewInit, ViewChild, ViewEncapsulation, OnInit } from '@angular/core';
import { NewsService } from '../news.service';
import { NewsArticle } from '../models/news-article.model';
import { Router } from '@angular/router';
@Component({
  selector: 'app-news-list',
  templateUrl: './news-list.component.html',
  styleUrls: ['./news-list.component.css'],
  encapsulation : ViewEncapsulation.None,
})
export class NewsListComponent implements OnInit {
  newsArticles: NewsArticle[] = [];
  pageSize = 5;
  currentPage = 1;
  totalItems = 0;
  searchTerm = '';

  constructor(private newsService: NewsService,private router: Router) {}

  ngOnInit() : void {
    if (this.searchTerm!=null) {
    this.loadNews();
    }
  }

  // loadLatestNews() {
  //   this.newsService.getLatestNews(1, 5).subscribe((articles) => (this.newsArticles = articles));
  // }

  loadNews() :void {
    this.newsService.getPaginatedNews(this.currentPage, this.pageSize, this.searchTerm)
      .subscribe((result: any) => {
        this.newsArticles = result.items;
        this.totalItems = result.totalItems;
      });
  }

  onPageChange(page: number):void {
    this.currentPage = page;
    this.loadNews();
  }

  onSearch(){
    if (this.searchTerm) {
      this.newsService.searchNews(this.searchTerm).subscribe((results) => (this.newsArticles = results));
    }
  }
  calculateTotalPages(): number {
    return Math.ceil(this.totalItems / this.pageSize);
  }

  deleteNews(id: number) {
    this.newsService.deleteNews(id).subscribe(() => {
      this.newsArticles = this.newsArticles.filter((article) => article.id !== id);
    });
  }
  editNews(newsId: number) {
    this.router.navigate(['/edit-news', newsId]);
  }
}
