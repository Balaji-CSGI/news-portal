// src/app/news-search/news-search.component.ts

import { Component } from '@angular/core';
import { NewsService } from '../news.service';
import { NewsArticle } from '../models/news-article.model';

@Component({
  selector: 'app-news-search',
  templateUrl: './news-search.component.html',
  styleUrls: ['./news-search.component.css'],
})
export class NewsSearchComponent {
  searchText: string = "";
  searchResults: NewsArticle[] = [];

  constructor(private newsService: NewsService) {}

  searchNews() {
    if (this.searchText) {
      this.newsService.searchNews(this.searchText).subscribe((results) => (this.searchResults = results));
    }
  }
}
